<?php
include "db_connect.php";

$uname  = $_GET['name'];
$umail = $_GET['mail'];
$upwd = $_GET['pwd'];
$uconpwd = $_GET['conpwd'];



?>